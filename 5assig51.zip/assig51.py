import os
import datetime
from flask import Flask

app = Flask(__name__)


@app.route('/')
def hello():
    now = datetime.datetime.now()
    print(now)
    yr = int(now.year)
    mth = int(now.month)
    day = int(now.day)
    hr = int(now.hour)
    min = int(now.minute)
    micsec = int(now.microsecond)
    date_to_timestamp1 = datetime.datetime(yr, mth, day, hr, min).timestamp()
    s = str(date_to_timestamp1)
    return s


if __name__ == "__main__":
   app.run()
