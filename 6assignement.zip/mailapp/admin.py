from django.contrib import admin
from mailapp.models import Mail

admin.site.register(Mail)
# Register your models here.
