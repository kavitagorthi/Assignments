from django.contrib import admin
from myblog.models import Post

admin.site.register(Post)

# Register your models here.
