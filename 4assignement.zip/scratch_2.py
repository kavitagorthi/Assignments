#!users/bin/env python
import cgi

print("content-type:text/plain")
print("")
form = cgi.FieldStorage()
str1 = form.getvalue('a',None)
str2 = form.getvalue('b',None)
str3 = form.getvalue('c',None)
int_str1 = int(str1)
int_str2 = int(str2)
oper = str3
res = 0
if(oper == '+'):
    res = int_str1+int_str2
    print("Number1 :{}",.format(int_str1))
    print("Number2 :{}",. format(int_str2))
    print("The result is {}", .format(res))
elif(oper == '-'):
    res = int_str1 - int_str2
    print("Number1 :{}", .format(int_str1))
    print("Number2 :{}", .format(int_str2))
    print("The result is {}",.format(res))
elif(oper == '/'):
    res = int_str1 / int_str2
    print("Number1 :{}",. format(int_str1))
    print("Number2 :{}",. format(int_str2))
    print("The result is {}",.format(res)
elif (oper == '*'):
    res = int_str1 * int_str2
    print("Number1 :{}",. format(int_str1))
    print("Number2 :{}", .format(int_str2))
    print("The result is {}",.format(res))
else:
    print("Enter the values of a and b and operand")
